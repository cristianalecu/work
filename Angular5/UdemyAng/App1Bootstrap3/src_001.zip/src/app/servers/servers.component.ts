import { Component, OnInit } from '@angular/core';

@Component({
  // selector: '[app-servers]',  // select  by attribute
  // selector: '.app-servers',   // select by class
  selector: 'app-servers',       // select by element name
  templateUrl: './servers.component.html',
  // template: `
  //  <app-server></app-server>
  //  <app-server></app-server>`,
  styleUrls: ['./servers.component.css'],
  // styles: [`
  //  h3 {
  //    color: dodgerblue;
  //  }
  // `]
})
export class ServersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
