### 1.0.1 (2016-11-30)
* Change help text to help disambiguate argument order.

### 1.0.0 (2016-11-02)
* Rename executable to `kinvey-bl`, and rename configuration file to `.kinvey-bl`.

### 0.8.0 (2016-10-13)
* Internal improvements.

### 0.7.0 (2016-03-28)
* Allow to initialize existing projects (i.e. where a `business-logic` directory already exists).
* Generate common test setup file as part of test stub generation.

### 0.6.0 (2015-12-03)
* Generate `mocha` test stubs when creating a collection hook or custom endpoint.

### 0.5.2 (2015-11-20)
* Fixed bug where the deploy function sometimes would not actually deploy.

### 0.5.1 (2015-09-30)
* Internal improvements.

### 0.5.0 (2015-09-16)
* Updated API to use `https://manage.kinvey.com`. You can still use the `--host` option to override this setting.

### 0.4.0 (2014-09-06)
* Updated the server to `https://legacy.kinvey.com`. You can still use the `--host` option to override this setting.

### 0.3.3 (2014-04-21)
* Fixed bug where the CLI would report "app not found" after the user session was refreshed.

### 0.3.2 (2014-03-04)
* Added `--host` option to configure the server to connect to.

### 0.3.1 (2014-02-07)
* Added support for managing Collection Hooks for users and files.
* Internal improvements.

### 0.3.0 (2014-01-29)
* Added a latest version check. A warning will be displayed when using an old version. Use `--suppress-version-check` to disable this behavior.
* Added prompt to generate command when script type is not specified.
* User credentials are now stored in the users home directory. App credentials remain in the project directory.

### 0.2.0 (2014-01-16)
* Internal refactoring
* Added support for common BL script files. For more details, check out the BL Revisions tutorial on the DevCenter (http://devcenter.kinvey.com/tutorials/business-logic-revisions#Addingcommoncode)

### 0.1.3
* Fixed an encoding bug that caused scripts with non-ASCII characters to fail most operations
* Fixed the handling of the --app command line argument
* Updated the rollback command to work with internal API changes
* Improved bundled Readme documentation
* Fixed encoding issue - files write out as unicode now

### 0.1.2 (2013-10-14)
* Message option is no longer required for deploys (an generated message will be used if none is supplied)
* Fixed a bug with the generate command's handling of numeric filenames

### 0.1.1 (2013-10-02)
* Minor bugfixes

### 0.1.0 (2013-09-30)
* Initial release