# Kinvey Business Logic CLI

With this command line tool you can:

* Edit your business logic using your editor of choice
* Manage and store code in your own version control repository
* Rollback a bad deploy

Your code will be stored in your project folder under the `business-logic` directory, organized by collection or custom endpoint name, for collection hooks and custom endpoints respectively.

Note: in general, you should **not** use Kinvey’s rollbacks as a version control system. Their purpose is to provide a quick fix in the case of a bad deployment, not a full-fledged replacement for git, svn, or other VCS.

## Setup

1. Copy the `kinvey-bl` binary in this folder to somewhere in your PATH (i.e. `/usr/local/bin` on Linux/OSX).
2. From the command line, navigate to the directory where you want to store your business logic code.
3. Run the `init` command to setup the folder with your business logic code and configuration:

```
~/my-project$ kinvey-bl init
```

4. Follow the remaining instructions provided by the CLI to complete the setup of your project.

Once you have initialized you will see a new `business-logic` directory generated. If you created any business logic code previously (e.g. using the web interface), the CLI will download it and create the necessary files for you.

## Making changes

Let's have you create a new custom endpoint, add a bit of code, and then deploy
the changes to Kinvey.

1. First up, run the `generate` command to scaffold out a basic template for your custom endpoint:

```
~/my-project$ kinvey-bl generate endpoint
```

2. Provide a name:

```
What would you like to call your custom endpoint? myTestEndpoint
Created file: ./business-logic/endpoints/myTestEndpoint.js
~/my-project$
```

3. Open the newly created file (`./business-logic/custom-endpoints/myTestEndpoint.js`), make a change to the code, and save it:

```
function onRequest(request, response, modules){
  modules.logger.info("It's working!");  // added
  response.continue();                   // don't forget this!
}
```

4. Run `kinvey-bl deploy` to have your changes deployed to the server.

## Rolling back
Revisions allow you to restore the state of your apps busines logic to a prior point in time. Each rollback doesn't undo your revision history; instead, it simply creates a new revision with the contents identical to the revision you rolled back to.

**WARNING:** Rollbacks are potentially dangerous operations! Use caution when rolling back code on a live production system. Rolling back will revert all your business logic associated with the app, not just a single collection hook or custom endpoint. If you need fine grained control over the history of your app's code, we encourage the use of a full-fledged version control system like Git. The purpose of revisions are to allow production bugs to be quickly reverted, not to provide a complete version control solution.

To rollback a deploy:

1. Navigate to your project folder in the command line.
2. Use the `rollback` command to roll back your deployed business logic to the previous state:

```
~/my-project$ kinvey-bl rollback
```

Beginning with version 0.5.0, `rollback` will only roll back to the previous version. It is not possible any more to rollback to any previous version. Use with caution.

## License

    Copyright 2016 Kinvey, Inc.

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.