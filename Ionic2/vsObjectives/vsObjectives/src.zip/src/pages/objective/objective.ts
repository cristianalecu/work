import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-objective',
  templateUrl: 'objective.html'
})
export class ObjectivePage {

  constructor(public navCtrl: NavController) {
  }
  
}
