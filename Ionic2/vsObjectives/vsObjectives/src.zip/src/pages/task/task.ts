import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-task',
  templateUrl: 'task.html'
})
export class TaskPage {

  constructor(public navCtrl: NavController) {
  }
  
}
